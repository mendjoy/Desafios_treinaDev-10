# Tabuada!

## Sim, tabuada! Vamos multiplicar números

Nesse desafio você precisa implementar o código de dois métodos: um para
retornar os múltiplos de um determinado número e outro para mostrar a tabuada de
determinados valores.
