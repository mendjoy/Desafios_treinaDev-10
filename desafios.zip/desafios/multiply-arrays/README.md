# Multiplicar e substituir

## Explorando mais um pouco de *arrays*

Você deve implementar o método para substituir cada posição do *array* pela
multiplicação do elemento anterior com o seguinte. Exemplos:

- [1, 2, 3, 4] deve retornar [2, 3, 8, 12]
- [2, 6, 7, 1, 3] deve retornar [12, 14, 6, 21, 3]
- [3, 1, 2, 8, 9, 5] deve retornar [3, 6, 8, 18, 40, 45]
