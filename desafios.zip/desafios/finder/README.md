# Encontre a posição

Neste desafio, você deve implementar o código que recebe um *array* e procura por todas as posições em que pode ser encontrado um caractere alvo. Por exemplo:

```ruby
['a', 'sw', 'f', 'y', 'xF', 'j']

'F' # string alvo
```

O resultado esperado para o exemplo acima é `4`.

**AVISO**: existe diferença entre letras minúsculas e maiúsculas.
