# Quantas vogais e consoantes?

## Vamos contar letras em strings

Nesse desafio você deve implementar dois métodos que lêem uma *string* e retornam,
respectivamente, a quantidade de vogais e de consoantes presentes nela.

Para este desafio, considere `y` uma vogal ;)