def soma(primeiro_numero, segundo_numero)
  primeiro_numero + segundo_numero
end

def subtracao(primeiro_numero, segundo_numero)
  primeiro_numero - segundo_numero
end

def multiplicacao(primeiro_numero, segundo_numero)
  primeiro_numero * segundo_numero
end

def divisao(x, y)
    return 'Opa! Zero como divisor' if y == 0
    x/y
end