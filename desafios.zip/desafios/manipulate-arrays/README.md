# Manipulando arrays!

## A diversão continua! Mais arrays \o/

Nesse desafio continuamos manipulando *arrays*. Dessa vez, você vai fazer
combinações, comparações, somar e encontrar divisíveis.
