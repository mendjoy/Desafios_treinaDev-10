# Arrays multidimensionais

## Vamos manipular listas, mas nada muito complicado ;)

Nesse desafio, vamos utilizar métodos para converter números e criar *arrays*
multidimensionais: *arrays* compostos de *arrays*. Da mesma forma que nos desafios
anteriores, clone e configure o repositório, depois rode o `rspec`. Se liga: as
mensagens que os testes retornam são parte crucial para o entendimento do
desafio.
